import styles from "./Home1.module.css";

const Home1 = () => {
  return (
    <div className={styles.home1}>
      <img
        className={styles.certificateMockup111}
        alt=""
        src="../certificate-mockup11-1@2x.png"
      />
      <div className={styles.home1Child} />
      <img className={styles.home1Item} alt="" src="../ellipse-18.svg" />
      <div className={styles.home1Inner} />
      <img className={styles.ellipseIcon} alt="" src="../ellipse-17.svg" />
      <div className={styles.rectangleDiv} />
      <img className={styles.home1Child1} alt="" src="../ellipse-16.svg" />
      <img className={styles.home1Child2} alt="" src="../ellipse-20.svg" />
      <div className={styles.home1Child3} />
      <button className={styles.vectorButton} />
      <img className={styles.vectorIcon} alt="" src="../vector-1.svg" />
      <img className={styles.home1Child4} alt="" src="../vector-6.svg" />
      <img className={styles.home1Child5} alt="" src="../vector-2.svg" />
      <b className={styles.advancedDigitalMarketingContainer}>
        <p className={styles.advancedDigitalMarketing}>
          ADVANCED DIGITAL MARKETING BOOTCAMP
        </p>
        <p className={styles.classroomLectures}>
          CLASSROOM LECTURES + LIVE PROJECTS
        </p>
      </b>
      <b className={styles.placementGuidance}>PLACEMENT GUIDANCE</b>
      <div className={styles.agencyBasedInstitute}>AGENCY BASED INSTITUTE</div>
      <div className={styles.practicalTrainingApproach}>
        PRACTICAL TRAINING APPROACH
      </div>
      <div className={styles.industryBasedGuidanceContainer}>
        <p className={styles.advancedDigitalMarketing}>INDUSTRY BASED</p>
        <p className={styles.classroomLectures}>GUIDANCE</p>
      </div>
      <img className={styles.people1Icon} alt="" src="../people-1@2x.png" />
      <img className={styles.goal6Icon} alt="" src="../goal-6@2x.png" />
      <img className={styles.chess2Icon} alt="" src="../chess-2@2x.png" />
      <img
        className={styles.handshake3Icon}
        alt=""
        src="../handshake-3@2x.png"
      />
      <div className={styles.upgradeYourSkillContainer}>
        <p
          className={styles.advancedDigitalMarketing}
        >{`Upgrade your skill set with Lit up’s certified digital marketing `}</p>
        <p className={styles.classroomLectures}>
          Classroom course and boost your career in just 2 months.
        </p>
      </div>
      <b className={styles.programCommencesJan}>
        Program Commences: Jan 30, 2023
      </b>
      <div className={styles.ellipseParent}>
        <img className={styles.groupChild} alt="" src="../ellipse-1.svg" />
        <b className={styles.viewCourse}>VIEW COURSE</b>
        <img className={styles.arrow11} alt="" src="../arrow-1-1@2x.png" />
      </div>
      <img className={styles.next21} alt="" src="../next-2-1@2x.png" />
      <img className={styles.next22} alt="" src="../next-2-2@2x.png" />
      <div className={styles.home1Child6} />
      <img className={styles.home1Child7} alt="" src="../ellipse-5.svg" />
      <div className={styles.home1Child8} />
      <div className={styles.home1Child9} />
      <div className={styles.home1Child10} />
      <div className={styles.home1Child11} />
      <div className={styles.weAreTheContainer}>
        <b>
          <span>WE ARE</span>
        </b>
        <span className={styles.theBestDigitalMarketingTra}>
          <b> THE</b>
          <i className={styles.best}> BEST</i>
          <b> DIGITAL MARKETING TRAINING INSTITUTE IN CHHATTISGARH</b>
        </span>
      </div>
      <b
        className={styles.courseCompletionCertificate}
      >{`Course Completion Certificate `}</b>
      <b className={styles.hubspotCertification}>Hubspot Certification</b>
      <b className={styles.semrushCertifications6}>
        SEMrush Certifications (6)
      </b>
      <b className={styles.googleMyBusiness}>
        Google My Business Certification
      </b>
      <b className={styles.googleMobileCertification}>
        Google Mobile Certification
      </b>
      <b className={styles.googleDisplayAds}>
        Google Display Ads Certification
      </b>
      <b className={styles.videoAdsCertification}>Video Ads Certification</b>
      <b className={styles.searchAdsCertification}>Search Ads Certification</b>
      <b className={styles.moduleSpecificCertification}>
        Module Specific Certification (11)
      </b>
      <b className={styles.shoppingAdsCertification}>
        Shopping Ads Certification
      </b>
      <b className={styles.certificates}>CERTIFICATES</b>
      <i className={styles.moreThan20CertificationsContainer}>
        <p className={styles.advancedDigitalMarketing}>MORE THAN 20</p>
        <p className={styles.classroomLectures}>CERTIFICATIONS</p>
      </i>
      <img
        className={styles.makeItHappen12}
        alt=""
        src="../makeithappen-1-2@2x.png"
      />
      <img className={styles.fire15} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire16} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire17} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire18} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire19} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire110} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire111} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire112} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire113} alt="" src="../fire-1-5@2x.png" />
      <img className={styles.fire114} alt="" src="../fire-1-5@2x.png" />
      <img
        className={styles.googleAnalyticsLogo3Icon}
        alt=""
        src="../googleanalyticslogo-3@2x.png"
      />
      <img
        className={styles.googleAnalyticsLogo4Icon}
        alt=""
        src="../googleanalyticslogo-4@2x.png"
      />
      <img
        className={styles.googleAdsLogoPng3Icon}
        alt=""
        src="../googleadslogopng-3@2x.png"
      />
      <img
        className={styles.googleAdsLogoPng4Icon}
        alt=""
        src="../googleadslogopng-4@2x.png"
      />
      <img
        className={styles.googleAdsenseLogo173Icon}
        alt=""
        src="../googleadsenselogo17-3@2x.png"
      />
      <img
        className={styles.googleAdsenseLogo174Icon}
        alt=""
        src="../googleadsenselogo17-4@2x.png"
      />
      <img
        className={styles.hubspotAcademyLogo11Icon}
        alt=""
        src="../hubspotacademylogo1-1@2x.png"
      />
      <img
        className={styles.linkedinLogoTransparentPngIcon}
        alt=""
        src="../linkedinlogotransparentpng25-2@2x.png"
      />
      <img
        className={styles.a409b3e59ee069da94c801Icon}
        alt=""
        src="../629a409b3e59ee069da94c80-1@2x.png"
      />
      <img
        className={styles.metaBlueprintLockupPositiveIcon}
        alt=""
        src="../meta-blueprint-lockup-positive-primary-rgb--281-29-1@2x.png"
      />
      <b className={styles.whyLitUp}>WHY LIT UP SOCIAL</b>
      <div className={styles.weProvideDigital}>
        We Provide Digital Marketing Based Educational programs to help you
        start, transition, or level-up your career.
      </div>
      <img className={styles.coffee12} alt="" src="../coffee-1-2@2x.png" />
      <img
        className={styles.portfolio11}
        alt=""
        src="../portfolio-1-1@2x.png"
      />
      <b className={styles.highestPlacementAssistanceContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Highest `}</p>
        <p className={styles.advancedDigitalMarketing}>Placement</p>
        <p className={styles.classroomLectures}>Assistance</p>
      </b>
      <b className={styles.internshipPostCourseCompleContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Internship `}</p>
        <p className={styles.advancedDigitalMarketing}>Post Course</p>
        <p className={styles.classroomLectures}>Completion</p>
      </b>
      <b className={styles.boosterClassesForContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Booster `}</p>
        <p className={styles.advancedDigitalMarketing}>{`Classes for `}</p>
        <p className={styles.classroomLectures}>Ex-Students</p>
      </b>
      <b className={styles.highestNumberOfContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Highest `}</p>
        <p className={styles.advancedDigitalMarketing}>Number of</p>
        <p className={styles.classroomLectures}>Certifications</p>
      </b>
      <img
        className={styles.certificate4Icon}
        alt=""
        src="../certificate-4@2x.png"
      />
      <b className={styles.industryExpertTeachersContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Industry `}</p>
        <p className={styles.advancedDigitalMarketing}>Expert</p>
        <p className={styles.classroomLectures}>Teachers</p>
      </b>
      <b className={styles.industryValuedCertifications}>
        <p className={styles.advancedDigitalMarketing}>20+ Industry</p>
        <p className={styles.advancedDigitalMarketing}>Valued</p>
        <p className={styles.classroomLectures}>Certifications</p>
      </b>
      <b className={styles.experienceWithLiveProjectsContainer}>
        <p className={styles.advancedDigitalMarketing}>Experience</p>
        <p className={styles.advancedDigitalMarketing}>with Live Projects</p>
      </b>
      <b className={styles.freeDomainHosting}>
        <p className={styles.advancedDigitalMarketing}>Free</p>
        <p className={styles.advancedDigitalMarketing}>{`Domain &`}</p>
        <p className={styles.classroomLectures}>Hosting</p>
      </b>
      <b className={styles.practicalAnd20TheoryContainer}>
        <p className={styles.advancedDigitalMarketing}>{`80% `}</p>
        <p className={styles.advancedDigitalMarketing}>Practical and</p>
        <p className={styles.classroomLectures}>20% Theory</p>
      </b>
      <b className={styles.mockInterviewPreparationsContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Mock `}</p>
        <p className={styles.advancedDigitalMarketing}>{`Interview &`}</p>
        <p className={styles.classroomLectures}>Preparations</p>
      </b>
      <b className={styles.resultOrientedTrainings}>
        <p className={styles.advancedDigitalMarketing}>Result</p>
        <p className={styles.advancedDigitalMarketing}>Oriented</p>
        <p className={styles.classroomLectures}>Trainings</p>
      </b>
      <b className={styles.lifetimeSupportToStudentContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Lifetime `}</p>
        <p className={styles.advancedDigitalMarketing}>Support to</p>
        <p className={styles.classroomLectures}>Student Queries</p>
      </b>
      <b className={styles.jobOrientedTraining}>
        <p className={styles.advancedDigitalMarketing}>100% Job</p>
        <p className={styles.advancedDigitalMarketing}>Oriented</p>
        <p className={styles.classroomLectures}>Training</p>
      </b>
      <b className={styles.unlimitedHotChocolate}>
        Unlimited Hot Chocolate Coffee
      </b>
      <img className={styles.teacher11} alt="" src="../teacher-1-1@2x.png" />
      <img
        className={styles.cloudUser1Icon}
        alt=""
        src="../clouduser-1@2x.png"
      />
      <img className={styles.goal41} alt="" src="../goal-4-1@2x.png" />
      <img
        className={styles.communityManager2Icon}
        alt=""
        src="../communitymanager-2@2x.png"
      />
      <img className={styles.female1Icon} alt="" src="../female-1@2x.png" />
      <b className={styles.premiumToolsToDriveResultsContainer}>
        <p className={styles.advancedDigitalMarketing}>25+ Premium</p>
        <p className={styles.advancedDigitalMarketing}>Tools to Drive</p>
        <p className={styles.classroomLectures}>Results</p>
      </b>
      <img className={styles.web21} alt="" src="../web-2-1@2x.png" />
      <img
        className={styles.certificate21}
        alt=""
        src="../certificate-2-1@2x.png"
      />
      <img className={styles.discount1Icon} alt="" src="../discount-1@2x.png" />
      <img className={styles.queries1Icon} alt="" src="../queries-1@2x.png" />
      <b className={styles.placementSupport}>
        <p className={styles.advancedDigitalMarketing}>100%</p>
        <p className={styles.classroomLectures}>Placement Support</p>
      </b>
      <img
        className={styles.clientSupport1Icon}
        alt=""
        src="../clientsupport-1@2x.png"
      />
      <img className={styles.launch1Icon} alt="" src="../launch-1@2x.png" />
      <b className={styles.agencyBasedInstitute1}>
        <p className={styles.advancedDigitalMarketing}>Agency</p>
        <p className={styles.advancedDigitalMarketing}>Based</p>
        <p className={styles.classroomLectures}>Institute</p>
      </b>
      <img className={styles.chart11} alt="" src="../chart-1-1@2x.png" />
      <img className={styles.bank12} alt="" src="../bank-1-2@2x.png" />
      <img
        className={styles.conversation41}
        alt=""
        src="../conversation-4-1@2x.png"
      />
      <b className={styles.learnUnleaern}>{`LEARN, UNLEAERN, & RELEARN.`}</b>
      <div className={styles.topDigitalMarketingContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Top Digital `}</p>
        <p
          className={styles.advancedDigitalMarketing}
        >{`Marketing Institute `}</p>
        <p className={styles.classroomLectures}>in Chhattisgarh</p>
      </div>
      <b className={styles.b}>1</b>
      <img
        className={styles.laurelWreath14}
        alt=""
        src="../laurelwreath-1-4@2x.png"
      />
      <div className={styles.characters171Parent}>
        <img
          className={styles.characters171Icon}
          alt=""
          src="../characters17-1@2x.png"
        />
        <img className={styles.groupItem} alt="" src="../rectangle-153.svg" />
        <b className={styles.registerForBootcamps}>REGISTER FOR BOOTCAMPS</b>
        <div className={styles.rectangleParent}>
          <div className={styles.groupInner} />
          <b className={styles.register}>REGISTER</b>
        </div>
      </div>
      <img
        className={styles.characters011Icon}
        alt=""
        src="../characters01-1@2x.png"
      />
      <img
        className={styles.characters041Icon}
        alt=""
        src="../characters04-1@2x.png"
      />
      <img
        className={styles.characters031Icon}
        alt=""
        src="../characters03-1@2x.png"
      />
      <img
        className={styles.characters091Icon}
        alt=""
        src="../characters09-1@2x.png"
      />
      <img
        className={styles.characters02Icon}
        alt=""
        src="../characters02@2x.png"
      />
      <img
        className={styles.characters12Icon}
        alt=""
        src="../characters12@2x.png"
      />
      <img
        className={styles.characters15Icon}
        alt=""
        src="../characters15@2x.png"
      />
      <img
        className={styles.characters16Icon}
        alt=""
        src="../characters16@2x.png"
      />
      <img
        className={styles.characters111Icon}
        alt=""
        src="../characters11-1@2x.png"
      />
      <div className={styles.home1Child12} />
      <b className={styles.advancedDigitalMarketing1}>
        Advanced Digital Marketing Bootcamp
      </b>
      <button className={styles.rectangleButton} />
      <div className={styles.classroomTraining}>CLASSROOM TRAINING</div>
      <div className={styles.months}>2 Months</div>
      <div className={styles.hoursLearning}>60+ hours learning</div>
      <div className={styles.certificate}>Certificate</div>
      <img
        className={styles.wallClock1Icon}
        alt=""
        src="../wallclock-1@2x.png"
      />
      <div className={styles.lineDiv} />
      <img className={styles.calendar1Icon} alt="" src="../calendar-1@2x.png" />
      <img className={styles.home1Child13} alt="" src="../ellipse-2.svg" />
      <div className={styles.topics30IndustryContainer}>
        <ul className={styles.topics30IndustryToolsMast}>
          <li className={styles.topics}>50+ Topics</li>
          <li className={styles.topics}>30+ Industry Tools Mastery</li>
          <li className={styles.topics}>20+ Certificates</li>
          <li
            className={styles.topics}
          >{`7+ Live Projects & Practice Assignments`}</li>
          <li className={styles.topics}>In-Class Live Presentations</li>
          <li className={styles.topics}>1-on-1 Mentoring Sessions</li>
          <li>Resources + Notes</li>
        </ul>
      </div>
      <img
        className={styles.certificate1Icon}
        alt=""
        src="../certificate-1@2x.png"
      />
      <div className={styles.rs25000}>Rs. 25,000</div>
      <div className={styles.rs40000}>Rs. 40,000</div>
      <b className={styles.off}>33% OFF</b>
      <div className={styles.home1Child14} />
      <img
        className={styles.bestOffer21}
        alt=""
        src="../bestoffer-2-1@2x.png"
      />
      <img
        className={styles.removebg1Icon}
        alt=""
        src="../03removebg-1@2x.png"
      />
      <div className={styles.home1Child15} />
      <img className={styles.home1Child16} alt="" src="../ellipse-12.svg" />
      <b className={styles.toolsTechnologies}>{`TOOLS & TECHNOLOGIES`}</b>
      <b className={styles.manyMore}>{`& Many More`}</b>
      <img
        className={styles.googleAdsLogoPng1Icon}
        alt=""
        src="../googleadslogopng-1@2x.png"
      />
      <img
        className={styles.googleAdsLogoPng2Icon}
        alt=""
        src="../googleadslogopng-2@2x.png"
      />
      <img
        className={styles.googleAnalyticsLogo1Icon}
        alt=""
        src="../googleanalyticslogo-1@2x.png"
      />
      <img
        className={styles.googleAnalyticsLogo2Icon}
        alt=""
        src="../googleanalyticslogo-2@2x.png"
      />
      <img
        className={styles.googleAdsenseLogo171Icon}
        alt=""
        src="../googleadsenselogo17-1@2x.png"
      />
      <img
        className={styles.googleAdsenseLogo172Icon}
        alt=""
        src="../googleadsenselogo17-2@2x.png"
      />
      <img
        className={styles.pxGoogleSearchConsole1Icon}
        alt=""
        src="../2560pxgoogle-search-console-1@2x.png"
      />
      <img
        className={styles.subpageConnectorLinkedin1Icon}
        alt=""
        src="../subpage-connector-linkedin-1@2x.png"
      />
      <img
        className={styles.linkedinLogoTransparentPngIcon1}
        alt=""
        src="../linkedinlogotransparentpng25-1@2x.png"
      />
      <img
        className={styles.figmaRemovebgPreviewIcon}
        alt=""
        src="../figmaremovebgpreview@2x.png"
      />
      <b className={styles.figma}>Figma</b>
      <b className={styles.interakt}>Interakt</b>
      <img className={styles.canvaIcon} alt="" src="../canva@2x.png" />
      <img className={styles.webflowIcon} alt="" src="../webflow@2x.png" />
      <img
        className={styles.mailerliteIcon}
        alt=""
        src="../mailerlite@2x.png"
      />
      <img
        className={styles.mailerliteIcon1}
        alt=""
        src="../mailerlite1@2x.png"
      />
      <button className={styles.surveymonkey} />
      <img className={styles.interaktIcon} alt="" src="../interakt@2x.png" />
      <img className={styles.spotifyIcon} alt="" src="../spotify@2x.png" />
      <img className={styles.mozIcon} alt="" src="../moz@2x.png" />
      <img className={styles.maskGroupIcon} alt="" src="../mask-group@2x.png" />
      <img
        className={styles.maskGroupIcon1}
        alt=""
        src="../mask-group1@2x.png"
      />
      <img
        className={styles.maskGroupIcon2}
        alt=""
        src="../mask-group2@2x.png"
      />
      <img
        className={styles.maskGroupIcon3}
        alt=""
        src="../mask-group3@2x.png"
      />
      <img
        className={styles.maskGroupIcon4}
        alt=""
        src="../mask-group4@2x.png"
      />
      <img
        className={styles.maskGroupIcon5}
        alt=""
        src="../mask-group5@2x.png"
      />
      <img
        className={styles.maskGroupIcon6}
        alt=""
        src="../mask-group6@2x.png"
      />
      <img
        className={styles.jungleScoutIcon}
        alt=""
        src="../jungle-scout@2x.png"
      />
      <img className={styles.semrushIcon} alt="" src="../semrush@2x.png" />
      <img
        className={styles.maskGroupIcon7}
        alt=""
        src="../mask-group7@2x.png"
      />
      <img
        className={styles.ubersuggestIcon}
        alt=""
        src="../ubersuggest@2x.png"
      />
      <img
        className={styles.longtailproIcon}
        alt=""
        src="../longtailpro@2x.png"
      />
      <img
        className={styles.amazonKindleLogoIcon}
        alt=""
        src="../amazonkindlelogo@2x.png"
      />
      <img
        className={styles.metaPlatformsIncLogo3Icon}
        alt=""
        src="../meta-platforms-inc-logo-3@2x.png"
      />
      <img className={styles.elementorIcon} alt="" src="../elementor@2x.png" />
      <img
        className={styles.googleMyBusinessLogo1Icon}
        alt=""
        src="../googlemybusinesslogo-1@2x.png"
      />
      <img
        className={styles.pngitem105589011Icon}
        alt=""
        src="../pngitem-10558901-1@2x.png"
      />
      <img
        className={styles.elementorIcon1}
        alt=""
        src="../elementor1@2x.png"
      />
      <img
        className={styles.maskGroupIcon8}
        alt=""
        src="../mask-group8@2x.png"
      />
      <img className={styles.kommoIcon} alt="" src="../kommo@2x.png" />
      <img
        className={styles.calendlyNewLogoIcon}
        alt=""
        src="../calendlynewlogo@2x.png"
      />
      <img
        className={styles.maskGroupIcon9}
        alt=""
        src="../mask-group9@2x.png"
      />
      <div className={styles.home1Child17} />
      <img className={styles.youtubeIcon} alt="" src="../youtube@2x.png" />
      <img
        className={styles.maskGroupIcon10}
        alt=""
        src="../mask-group10@2x.png"
      />
      <img className={styles.shopifyIcon} alt="" src="../shopify@2x.png" />
      <img className={styles.woorankIcon} alt="" src="../woorank@2x.png" />
      <img className={styles.quillbotIcon} alt="" src="../quillbot@2x.png" />
      <img className={styles.snapchatIcon} alt="" src="../snapchat@2x.png" />
      <img
        className={styles.yoastSeoRemovebgPreviewIcon}
        alt=""
        src="../yoast-seoremovebgpreview@2x.png"
      />
      <img className={styles.twitterIcon} alt="" src="../twitter@2x.png" />
      <img className={styles.wordpressIcon} alt="" src="../wordpress@2x.png" />
      <img
        className={styles.mailChimpRemovebgPreviewIcon}
        alt=""
        src="../mail-chimpremovebgpreview@2x.png"
      />
      <img
        className={styles.maskGroupIcon11}
        alt=""
        src="../mask-group11@2x.png"
      />
      <img className={styles.spyfuIcon} alt="" src="../spyfu@2x.png" />
      <img className={styles.serpStatIcon} alt="" src="../serp-stat@2x.png" />
      <img
        className={styles.googleLogoPngWebinarOptimiIcon}
        alt=""
        src="../googlelogopngwebinaroptimizingforsuccessgooglebusinesswebinar13-1@2x.png"
      />
      <img className={styles.sales12} alt="" src="../sales-1-2@2x.png" />
      <img className={styles.quoraIcon} alt="" src="../quora@2x.png" />
      <b className={styles.jungle}>Jungle</b>
      <b className={styles.longtail}>LongTail</b>
      <b className={styles.b1}>1</b>
      <img
        className={styles.laurelWreath1Icon}
        alt=""
        src="../laurelwreath-1@2x.png"
      />
      <b
        className={styles.trainersSpeakers}
      >{`TRAINERS, SPEAKERS, & MENTORS`}</b>
      <div className={styles.eachAspectOf}>
        Each aspect of our training is covered by subject area experts and
        digital enthusiasts. The course curriculum is curated and fine tuned
        with the help of their know-how and experience. Their knowledge and
        expertise is instrumental in moulding our students into skilled
        professionals of the future.
      </div>
      <button className={styles.home1Child18} />
      <button className={styles.home1Child19} />
      <div className={styles.home1Child20} />
      <i className={styles.trainers}>TRAINERS</i>
      <b className={styles.mentors}>MENTORS</b>
      <b className={styles.superSessionSpeakers}>SUPER SESSION SPEAKERS</b>
      <b className={styles.educationThatGetsContainer}>
        <p className={styles.advancedDigitalMarketing}>EDUCATION THAT GETS</p>
        <p className={styles.classroomLectures}>YOU INDUSTRY-READY</p>
      </b>
      <div className={styles.learnHowThisContainer}>
        <b>
          <span>LEARN HOW</span>
          <span className={styles.this}> THIS</span>
          <span className={styles.theBestDigitalMarketingTra}>{` `}</span>
        </b>
        <i className={styles.digitalMarketingCourse}>
          DIGITAL MARKETING COURSE
        </i>
        <b>
          <span className={styles.theBestDigitalMarketingTra}>{` `}</span>
          <span className={styles.this}>WILL</span>
          <span> TRANSFORM YOUR CAREER</span>
        </b>
      </div>
      <div className={styles.eachAspectOf1}>
        Each aspect of our training is covered by subject area experts and
        digital enthusiasts. The course curriculum is curated and fine tuned
        with the help of their know-how and experience. Their knowledge and
        expertise is instrumental in moulding our students into skilled
        professionals of the future.
      </div>
      <b className={styles.topDigitalMarketingContainer1}>
        <p className={styles.advancedDigitalMarketing}>{`Top Digital `}</p>
        <p
          className={styles.advancedDigitalMarketing}
        >{`Marketing Institute `}</p>
        <p className={styles.classroomLectures}>in Chhattisgarh</p>
      </b>
      <b className={styles.communityLedLearning}>COMMUNITY-LED LEARNING</b>
      <div className={styles.weAtLit}>
        We at Lit up Social facilitate a dynamic community to build real-world
        problem-solving skills.
      </div>
      <b className={styles.trainers1}>Trainers</b>
      <b className={styles.programmes}>Programmes</b>
      <i className={styles.i}>
        <span>20</span>
        <span className={styles.span2}>+</span>
      </i>
      <i className={styles.i1}>
        <span>20</span>
        <span className={styles.span2}>{`+ `}</span>
      </i>
      <b className={styles.b2}>1</b>
      <b className={styles.b3}>1</b>
      <b className={styles.certifications3}>Certifications</b>
      <i className={styles.i2}>
        <span>20</span>
        <span className={styles.span2}>{`+ `}</span>
      </i>
      <b className={styles.industryTools}>Industry Tools</b>
      <i className={styles.i3}>
        <span>50</span>
        <span className={styles.span2}>{`+ `}</span>
      </i>
      <div className={styles.home1Child21} />
      <div className={styles.home1Child22} />
      <b className={styles.mentors1}>MENTORS</b>
      <b className={styles.superSessionSpeakers1}>SUPER SESSION SPEAKERS</b>
      <img className={styles.discord1Icon} alt="" src="../discord-1@2x.png" />
      <img
        className={styles.laurelWreath11}
        alt=""
        src="../laurelwreath-1-4@2x.png"
      />
      <b className={styles.largestTeamOfContainer}>
        <p className={styles.advancedDigitalMarketing}>{`Largest team of `}</p>
        <p
          className={styles.advancedDigitalMarketing}
        >{`Trainers & Mentors `}</p>
        <p className={styles.classroomLectures}>in Chhattisgarh</p>
      </b>
      <b className={styles.b4}>1</b>
      <img
        className={styles.laurelWreath6Icon}
        alt=""
        src="../laurelwreath-1@2x.png"
      />
      <b className={styles.largestTeamOfContainer1}>
        <p className={styles.advancedDigitalMarketing}>{`Largest team of `}</p>
        <p
          className={styles.advancedDigitalMarketing}
        >{`Trainers & Mentors `}</p>
        <p className={styles.classroomLectures}>in Chhattisgarh</p>
      </b>
      <b className={styles.b5}>1</b>
      <img
        className={styles.laurelWreath4Icon}
        alt=""
        src="../laurelwreath-1@2x.png"
      />
      <b className={styles.largestPoolOf}>
        Largest Pool of Tools covering more than 50+ Tools.
      </b>
      <b className={styles.b6}>1</b>
      <img
        className={styles.laurelWreath5Icon}
        alt=""
        src="../laurelwreath-1@2x.png"
      />
      <b className={styles.comprehensiveLevelCertificat}>
        Comprehensive Level Certifications in Digital Marketing
      </b>
      <div className={styles.topDigitalMarketingContainer2}>
        <p className={styles.advancedDigitalMarketing}>{`Top Digital `}</p>
        <p
          className={styles.advancedDigitalMarketing}
        >{`Marketing Institute `}</p>
        <p className={styles.classroomLectures}>in Chhattisgarh</p>
      </div>
      <img
        className={styles.laurelWreath12}
        alt=""
        src="../laurelwreath-1-4@2x.png"
      />
      <img className={styles.home1Child23} alt="" src="../ellipse-6.svg" />
      <img className={styles.home1Child24} alt="" src="../ellipse-7.svg" />
      <img className={styles.home1Child25} alt="" src="../ellipse-8.svg" />
      <img className={styles.home1Child26} alt="" src="../ellipse-9.svg" />
      <img className={styles.home1Child27} alt="" src="../ellipse-10.svg" />
      <img className={styles.home1Child28} alt="" src="../ellipse-11.svg" />
      <img className={styles.speak11} alt="" src="../speak-1-1@2x.png" />
      <img className={styles.messages11} alt="" src="../messages-1-1@2x.png" />
      <img className={styles.learning1Icon} alt="" src="../learning-1@2x.png" />
      <img className={styles.lineIcon} alt="" src="../line-9.svg" />
      <img className={styles.team11} alt="" src="../team-1-1@2x.png" />
      <img
        className={styles.christmasDay11}
        alt=""
        src="../christmasday-1-1@2x.png"
      />
      <img
        className={styles.careerChoice11}
        alt=""
        src="../careerchoice-1-1@2x.png"
      />
      <b className={styles.interactWithThe}>Interact with the best</b>
      <div className={styles.goBeyondPreRecorded}>
        Go beyond pre-recorded courses with Lit up Social LIVE and get doubts
        cleared personally
      </div>
      <b className={styles.buildRelationshipsBeyond}>
        Build Relationships Beyond Networks
      </b>
      <div className={styles.workWithMotivated}>
        Work with motivated peers having fresh out-of-the-box thinking and
        showing you new ways to do things.
      </div>
      <b className={styles.liveEventsTo}>Live Events to Engage In</b>
      <div
        className={styles.participateInLive}
      >{`Participate in live Q&As, debates, hackathons, and other healthy contests to drive home the learning.`}</div>
      <b className={styles.findCareerOpportunities}>
        Find Career Opportunities
      </b>
      <div className={styles.becomeAPart}>
        Become a part of an ecosystem where members help access opportunities
        for jobs and freelance projects.
      </div>
      <div className={styles.actionableProgramsTo}>
        Actionable programs to offset the Pareto Principle; you will execute
        projects using what you learned
      </div>
      <b className={styles.theCommunityAt}>The Community at the center</b>
      <b className={styles.learnByDoing}>Learn by Doing</b>
      <div className={styles.enjoyTheBest}>
        Enjoy the best of peer-led learning with tons of events while building
        lifelong relationships
      </div>
      <div className={styles.home1Child29} />
      <img className={styles.fire2Icon} alt="" src="../fire-2@2x.png" />
      <div className={styles.ankitThakur}>ANKIT THAKUR</div>
      <div className={styles.abhishekSoni}>ABHISHEK SONI</div>
      <div className={styles.abhijeetMishra}>ABHIJEET MISHRA</div>
      <div className={styles.vartikaGandhi}>VARTIKA GANDHI</div>
      <div className={styles.aparnaShrivastava}>APARNA SHRIVASTAVA</div>
      <div className={styles.palakDewangan}>PALAK DEWANGAN</div>
      <div className={styles.rajatDubey}>RAJAT DUBEY</div>
      <div className={styles.princeVarghese}>PRINCE VARGHESE</div>
      <img className={styles.home1Child30} alt="" src="../ellipse-3.svg" />
      <img className={styles.home1Child31} alt="" src="../ellipse-3.svg" />
      <img className={styles.home1Child32} alt="" src="../ellipse-111.svg" />
      <img className={styles.home1Child33} alt="" src="../ellipse-3.svg" />
      <img className={styles.home1Child34} alt="" src="../ellipse-3.svg" />
      <img className={styles.home1Child35} alt="" src="../ellipse-3.svg" />
      <img className={styles.home1Child36} alt="" src="../ellipse-111.svg" />
      <img className={styles.home1Child37} alt="" src="../ellipse-3.svg" />
      <div
        className={styles.advertisementsAcrossMeta}
      >{`Advertisements across Meta & Google`}</div>
      <div
        className={styles.advertisementsAcrossMeta1}
      >{`Advertisements across Meta & Google`}</div>
      <div className={styles.ellipseGroup}>
        <img className={styles.groupChild} alt="" src="../ellipse-1.svg" />
        <b className={styles.viewCourse}>VIEW COURSE</b>
        <img className={styles.arrow11} alt="" src="../arrow-1-1@2x.png" />
      </div>
      <img className={styles.rectangleIcon} alt="" src="../rectangle-17.svg" />
      <b className={styles.letsDisucss}>
        <p className={styles.advancedDigitalMarketing}>{`Let’s `}</p>
        <p className={styles.classroomLectures}>Disucss</p>
      </b>
      <button className={styles.rectangleGroup}>
        <button className={styles.groupChild2} />
        <div className={styles.discuss}>Discuss</div>
      </button>
      <button className={styles.rectangleContainer}>
        <button className={styles.groupChild3} />
        <div className={styles.freeCoffee}>Free Coffee</div>
      </button>
      <img className={styles.coffee11} alt="" src="../coffee-1-2@2x.png" />
      <img className={styles.home1Child38} alt="" src="../ellipse-14.svg" />
      <img className={styles.person2Icon} alt="" src="../person-2@2x.png" />
      <div className={styles.groupDiv}>
        <div className={styles.groupWrapper}>
          <div className={styles.groupWrapper}>
            <div className={styles.groupChild4} />
            <b className={styles.joinNowTo}>
              Join Now to Master Your Skills in Digital Marketing Today
            </b>
            <img
              className={styles.person12}
              alt=""
              src="../person-1-2@2x.png"
            />
          </div>
        </div>
      </div>
      <img
        className={styles.characters181Icon}
        alt=""
        src="../characters18-1@2x.png"
      />
      <button className={styles.groupButton}>
        <button className={styles.groupChild5} />
        <b className={styles.download}>DOWNLOAD</b>
      </button>
      <b className={styles.downloadBrochure}>DOWNLOAD BROCHURE</b>
      <div className={styles.home1Child39} />
      <div className={styles.home1Child40} />
      <input className={styles.rectangleInput} type="text" />
      <div className={styles.home1Child41} />
      <input className={styles.home1Child42} type="text" />
      <input className={styles.home1Child43} type="text" />
      <input className={styles.home1Child44} type="text" />
      <input className={styles.home1Child45} type="text" />
      <input className={styles.home1Child46} type="text" />
      <input className={styles.home1Child47} type="text" />
      <input className={styles.home1Child48} type="text" />
      <img
        className={styles.youHaveGotIt4Icon}
        alt=""
        src="../youhavegotit-4@2x.png"
      />
      <input className={styles.home1Child49} type="text" />
      <div className={styles.home1Child50} />
      <input className={styles.home1Child51} type="text" />
      <input className={styles.home1Child52} type="text" />
      <input className={styles.home1Child53} type="text" />
      <input className={styles.home1Child54} type="text" />
      <img className={styles.fire139} alt="" src="../fire-1-39@2x.png" />
      <button className={styles.rectangleParent2}>
        <button className={styles.groupChild6} />
        <img className={styles.person31} alt="" src="../person-3-1@2x.png" />
        <b className={styles.registerNow}>REGISTER NOW</b>
      </button>
      <b className={styles.bookAFreeContainer}>
        <span>{`Book a `}</span>
        <span className={styles.free1}>Free</span>
        <span> Demo</span>
      </b>
      <b className={styles.studentsFirstName}>Student’s First Name</b>
      <b className={styles.studentsLastName}>Student’s Last Name</b>
      <b className={styles.birthDate}>Birth Date</b>
      <b className={styles.month}>Month</b>
      <img className={styles.polygonIcon} alt="" src="../polygon-6.svg" />
      <b className={styles.day}>Day</b>
      <img className={styles.home1Child55} alt="" src="../polygon-6.svg" />
      <b className={styles.year}>Year</b>
      <img className={styles.home1Child56} alt="" src="../polygon-6.svg" />
      <b className={styles.gender}>Gender</b>
      <img className={styles.home1Child57} alt="" src="../polygon-6.svg" />
      <b className={styles.streetAddress}>Street Address</b>
      <b className={styles.city}>City</b>
      <b className={styles.stateProvince}>State / Province</b>
      <b className={styles.postalZip}>Postal / Zip Code</b>
      <b className={styles.studentsEMail}>Student’s E-mail</b>
      <b className={styles.studentsPhoneNumber}>Student’s Phone Number</b>
      <b className={styles.nameOfCollegeuniversity}>
        Name of College/University
      </b>
      <b className={styles.degreeCourse}>Degree / Course / Diploma</b>
      <b className={styles.courseName}>Course Name</b>
      <img className={styles.home1Child58} alt="" src="../polygon-5.svg" />
      <div className={styles.iAgreeLitContainer}>
        <span className={styles.iAgreeLit}>{`I agree Lit Up Social’s `}</span>
        <b>Terms and Conditions</b>
        <span className={styles.iAgreeLit}>{` and their `}</span>
        <b>Privacy Policy</b>
        <span className={styles.iAgreeLit}>{`   `}</span>
      </div>
      <input
        className={styles.home1Child59}
        type="checkbox"
        defaultChecked={true}
      />
      <div className={styles.rectangleParent3}>
        <div className={styles.groupChild7} />
        <b className={styles.submit}>Submit</b>
      </div>
      <img
        className={styles.presentationTemplate051}
        alt=""
        src="../presentation-template05-1@2x.png"
      />
      <b className={styles.hoursOfLearning}>Hours of Learning</b>
      <b className={styles.brandProjects}>Brand Projects</b>
      <i className={styles.i4}>
        <span>100</span>
        <span className={styles.span2}>+</span>
      </i>
      <i className={styles.i5}>
        <span>07</span>
        <span className={styles.span2}>{`+ `}</span>
      </i>
      <b className={styles.certifications4}>Certifications</b>
      <i className={styles.i6}>
        <span>20</span>
        <span className={styles.span2}>{`+ `}</span>
      </i>
      <b className={styles.topicsModules}>{`Topics & Modules`}</b>
      <i className={styles.i7}>
        <span>50</span>
        <span className={styles.span2}>{`+ `}</span>
      </i>
      <button className={styles.talkToAnExpertParent}>
        <i className={styles.talkToAn}>TALK TO AN EXPERT</i>
        <button className={styles.groupChild8} />
      </button>
      <div className={styles.downloadBrochureParent}>
        <b className={styles.downloadBrochure1}>DOWNLOAD BROCHURE</b>
        <div className={styles.groupChild9} />
      </div>
      <div className={styles.rectangleParent4}>
        <div className={styles.groupChild10} />
        <b className={styles.joinNowTo}>
          Join Now to Master Your Skills in Digital Marketing Today
        </b>
        <img className={styles.person12} alt="" src="../person-1-2@2x.png" />
      </div>
      <img className={styles.gvk1Icon} alt="" src="../gvk-1@2x.png" />
      <button className={styles.ellipseContainer}>
        <img className={styles.groupChild11} alt="" src="../ellipse-1.svg" />
        <b className={styles.hellYeah}>HELL YEAH!</b>
      </button>
      <div className={styles.areYouReadyContainer}>
        <b>
          <span>ARE YOU</span>
          <span className={styles.theBestDigitalMarketingTra}>{` `}</span>
        </b>
        <i className={styles.digitalMarketingCourse}>READY</i>
        <b className={styles.theBestDigitalMarketingTra}>
          {" "}
          TO BUILD YOUR DIGITAL FUTURE?
        </b>
      </div>
      <img
        className={styles.rightArrow21}
        alt=""
        src="../rightarrow-2-1@2x.png"
      />
      <img className={styles.home1Child60} alt="" src="../ellipse-31.svg" />
      <img className={styles.person1Icon} alt="" src="../person-2@2x.png" />
      <img
        className={styles.presentationTemplate064}
        alt=""
        src="../presentation-template06-4@2x.png"
      />
      <div className={styles.home1Child61} />
      <i className={styles.subscribeToOur}>SUBSCRIBE TO OUR NEWSLETTER</i>
      <b className={styles.followUs}>Follow us:</b>
      <div className={styles.getUpdatesOn}>
        Get updates on new programs, workshops, the latest developments, and
        community activities, straight to your inbox.
      </div>
      <img
        className={styles.instagram2Icon}
        alt=""
        src="../instagram-2@2x.png"
      />
      <img className={styles.linkedin1Icon} alt="" src="../linkedin-1@2x.png" />
      <img className={styles.twitter2Icon} alt="" src="../twitter-2@2x.png" />
      <img className={styles.youtube2Icon} alt="" src="../youtube-2@2x.png" />
      <img className={styles.behance2Icon} alt="" src="../behance-2@2x.png" />
      <img className={styles.facebook1Icon} alt="" src="../facebook-1@2x.png" />
      <img className={styles.discord17} alt="" src="../discord-1-7@2x.png" />
      <b className={styles.programmes1}>Programmes</b>
      <b className={styles.aboutUs}>About Us</b>
      <b className={styles.contactUs}>Contact Us</b>
      <b className={styles.bootcamps}>Bootcamps</b>
      <b className={styles.joinAsA}>Join as a Mentor</b>
      <b className={styles.resources}>Resources</b>
      <b className={styles.placements}>Placements</b>
      <b className={styles.freeCoffee1}>Free Coffee</b>
      <b className={styles.hireFromUs}>Hire from us</b>
      <b className={styles.knowledgePortal}>Knowledge Portal</b>
      <b className={styles.playbooks}>Playbooks</b>
      <b className={styles.faqs}>FAQs</b>
      <a className={styles.privacyPolicy}>Privacy Policy</a>
      <b className={styles.blogs}>Blogs</b>
      <b className={styles.termsConditions}>{`Terms & Conditions`}</b>
      <img
        className={styles.theDigiJugadLogoAndColors}
        alt=""
        src="../the-digi-jugad-logo-and-colors20-1-8@2x.png"
      />
      <img
        className={styles.makeItHappen7Icon}
        alt=""
        src="../makeithappen-7@2x.png"
      />
      <div className={styles.topDigitalMarketing}>
        Top Digital Marketing Institute in Chhattisgarh
      </div>
      <div className={styles.bestDigitalMarketing}>
        Best Digital Marketing Institute in Chhattisgarh
      </div>
      <div className={styles.topDigitalMarketing1}>
        Top Digital Marketing Institute in Bhilai
      </div>
      <div className={styles.bestDigitalMarketing1}>
        Best Digital Marketing Institute in Bhilai
      </div>
      <div className={styles.learnDigitalMarketing}>
        Learn Digital Marketing
      </div>
      <div className={styles.digitalMarketingPhysical}>
        Digital Marketing Physical Classes Near me
      </div>
      <div
        className={styles.digitalMarketingTraining}
      >{`Digital Marketing Training & Coaching`}</div>
      <div className={styles.litUpSocial}>
        Lit up social digital marketing academy
      </div>
      <div className={styles.seoCoursesInstitute}>
        SEO Courses Institute in Bhilai
      </div>
      <div className={styles.digitalMarketingAcademy}>
        Digital Marketing Academy in Chhattisgarh
      </div>
      <div className={styles.digitalMarketingAcademy1}>
        Digital Marketing Academy in Bhilai
      </div>
      <div className={styles.bestAgencyBasedDigital}>
        Best Agency-Based Digital Marketing Institute
      </div>
      <div className={styles.bestPlacementRecord}>
        Best Placement Record Digital Marketing Institute
      </div>
      <div
        className={styles.bestDigitalMarketing2}
      >{`Best Digital Marketing Trainers & Teachers`}</div>
      <div
        className={styles.topDigitalMarketing2}
      >{`Top Digital Marketing Trainer & Teachers`}</div>
      <div className={styles.digitalMarketingTraining1}>
        Digital Marketing Training in Bhilai
      </div>
      <div
        className={styles.bootcampsOffline}
      >{`Bootcamps & Offline Batches`}</div>
      <div className={styles.liveProjectExperience}>
        Live Project Experience in Digital Marketing
      </div>
      <div
        className={styles.internshipsExperience}
      >{`Internships & Experience in Digital Marketing`}</div>
      <div className={styles.digitalMarketingCourses}>
        Digital marketing courses for freshers
      </div>
      <div className={styles.entryLevelTraining}>Entry Level Training</div>
      <div className={styles.comprehensiveLevelTrainings}>
        Comprehensive Level Trainings
      </div>
      <div className={styles.digitalMarketingCertificatio}>
        Digital Marketing Certification Courses in Bhilai, Chhattisgarh
      </div>
      <div className={styles.seoCertificationCourses}>
        SEO Certification Courses in Bhilai, Chhattisgarh
      </div>
      <div className={styles.bestDigitalMarketing3}>
        Best digital marketing Certification Course bhilai
      </div>
      <div className={styles.careerOptions2023}>Career options 2023</div>
      <div className={styles.becomeAProfessional}>
        Become a professional digital marketer
      </div>
      <div className={styles.onlineMarketingCourse}>
        Online marketing course for beginners
      </div>
      <div className={styles.onlineClassesFor}>
        Online Classes for Digital Marketing
      </div>
      <div className={styles.careerInDigital}>Career in Digital Marketing</div>
      <div className={styles.upskillingInDigital}>
        Upskilling in Digital Marketing Profession
      </div>
      <div className={styles.corporateDigitalMarketing}>
        Corporate Digital Marketing Training Institute
      </div>
      <div
        className={styles.liveProject}
      >{`Live Project & Case Studies in Digital Marketing`}</div>
      <div
        className={styles.digitalMarketingJob}
      >{`Digital Marketing Job Interview Preperation `}</div>
      <div className={styles.digitalMarketingInterview}>
        Digital Marketing Interview Questions
      </div>
      <div className={styles.digitalMarketingFree}>
        Digital Marketing free resources
      </div>
      <div className={styles.home1Child62} />
      <img className={styles.next33} alt="" src="../next-3-3@2x.png" />
      <div className={styles.enterYourEmail}>Enter your email</div>
      <img
        className={styles.presentationTemplate0641}
        alt=""
        src="../presentation-template06-41@2x.png"
      />
      <b className={styles.supportHelpline}>
        <p className={styles.advancedDigitalMarketing}>{`Support `}</p>
        <p className={styles.classroomLectures}>Helpline</p>
      </b>
      <img
        className={styles.headphonesIcon}
        alt=""
        src="../headphones@2x.png"
      />
      <b className={styles.about}>ABOUT</b>
      <b className={styles.workWithUs}>WORK WITH US</b>
      <b className={styles.knowledgePortal1}>KNOWLEDGE PORTAL</b>
      <b className={styles.contact}>CONTACT</b>
      <b className={styles.community}>COMMUNITY</b>
      <i className={styles.programs}>PROGRAMS</i>
      <button className={styles.home1Child63} />
      <img className={styles.home1Child64} alt="" src="../polygon-15.svg" />
      <img className={styles.home1Child65} alt="" src="../polygon-21.svg" />
      <input className={styles.home1Child66} type="text" />
    </div>
  );
};

export default Home1;
